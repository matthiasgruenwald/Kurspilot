<?php
// This file is part of Moodle - http://moodle.org/

namespace local_aicoursecreator\external;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/externallib.php');
require_once($CFG->libdir . '/questionlib.php');

use external_api;
use external_function_parameters;
use external_value;
use external_single_structure;
use external_multiple_structure;

/**
 * Liefert die latest version einer Frage in einer Kategorie, eindeutig
 * identifiziert per Name ODER per questionid (ID einer beliebigen Version
 * derselben Frage).
 *
 * Liefert auch die Antwort-Optionen und kennzeichnet die richtige Antwort,
 * damit Aufrufer (z.B. der MCP-Server) vor einem Edit sehen, mit welcher
 * Frage gearbeitet wird.
 */
class get_question extends external_api {

    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'categoryid' => new external_value(PARAM_INT,  'ID der Fragenbank-Kategorie'),
            'name'       => new external_value(PARAM_TEXT, 'Name der Frage (alternativ zu questionid)', VALUE_DEFAULT, ''),
            'questionid' => new external_value(PARAM_INT,  'questionid einer beliebigen Version der Frage (alternativ zu name)', VALUE_DEFAULT, 0),
        ]);
    }

    public static function execute(int $categoryid, string $name = '', int $questionid = 0): array {
        global $DB;

        $params = self::validate_parameters(self::execute_parameters(), [
            'categoryid' => $categoryid,
            'name'       => $name,
            'questionid' => $questionid,
        ]);

        if ($params['name'] === '' && $params['questionid'] === 0) {
            throw new \invalid_parameter_exception(
                'Es muss entweder name oder questionid angegeben werden.');
        }

        $category = $DB->get_record('question_category',
            ['id' => $params['categoryid']], '*', MUST_EXIST);
        $context = \context::instance_by_id($category->contextid);
        self::validate_context($context);
        require_capability('moodle/question:view', $context);

        // questionbankentryid bestimmen.
        $entryid = $params['questionid'] > 0
            ? self::entry_id_from_questionid((int) $params['questionid'])
            : self::entry_id_from_name((int) $params['categoryid'], (string) $params['name']);

        if ($entryid === 0) {
            throw new \moodle_exception('notfound', 'error', '',
                null, 'Keine Frage gefunden fuer die uebergebenen Kriterien.');
        }

        // Latest Version dieser Entry laden.
        $latest = $DB->get_record_sql(
            'SELECT * FROM {question_versions}
              WHERE questionbankentryid = ?
           ORDER BY version DESC',
            [$entryid],
            IGNORE_MULTIPLE
        );
        if (!$latest) {
            throw new \moodle_exception('notfound', 'error', '',
                null, 'Keine Version fuer questionbankentryid ' . $entryid . ' gefunden.');
        }

        $question = $DB->get_record('question',
            ['id' => $latest->questionid], '*', MUST_EXIST);

        // Antworten laden (in der Reihenfolge ihrer IDs = Anlege-Reihenfolge).
        $answers = $DB->get_records('question_answers',
            ['question' => $question->id], 'id ASC');

        $answerlist = [];
        $correctindex = -1;
        $i = 0;
        foreach ($answers as $a) {
            $answerlist[] = [
                'id'       => (int) $a->id,
                'answer'   => (string) $a->answer,
                'fraction' => (float) $a->fraction,
            ];
            if ((float) $a->fraction >= 1.0 && $correctindex === -1) {
                $correctindex = $i;
            }
            $i++;
        }

        return [
            'questionid'          => (int) $question->id,
            'questionbankentryid' => (int) $entryid,
            'version'             => (int) $latest->version,
            'name'                => (string) $question->name,
            'questiontext'        => (string) $question->questiontext,
            'qtype'               => (string) $question->qtype,
            'defaultmark'         => (float)  $question->defaultmark,
            'answers'             => $answerlist,
            'correctindex'        => $correctindex,
        ];
    }

    /**
     * Entry-ID ueber eine bekannte questionid (irgendeine Version) ermitteln.
     */
    private static function entry_id_from_questionid(int $questionid): int {
        global $DB;
        $v = $DB->get_record('question_versions', ['questionid' => $questionid]);
        return $v ? (int) $v->questionbankentryid : 0;
    }

    /**
     * Entry-ID ueber Kategorie + Frage-Name ermitteln (eindeutig anhand der
     * latest version, da der Name historisch in question.name liegt).
     * Bei mehreren Treffern wird der mit der hoechsten Version genommen.
     */
    private static function entry_id_from_name(int $categoryid, string $name): int {
        global $DB;
        // Join: Entry in Kategorie -> latest version -> question mit gesuchtem Namen.
        $sql = 'SELECT qbe.id AS entryid, qv.version AS version
                  FROM {question_bank_entries} qbe
                  JOIN {question_versions} qv ON qv.questionbankentryid = qbe.id
                  JOIN {question} q           ON q.id = qv.questionid
                 WHERE qbe.questioncategoryid = :catid
                   AND q.name = :name
              ORDER BY qbe.id ASC, qv.version DESC';
        $rows = $DB->get_records_sql($sql, ['catid' => $categoryid, 'name' => $name]);
        if (!$rows) {
            return 0;
        }
        // Erste Entry mit Match nehmen.
        $first = reset($rows);
        return (int) $first->entryid;
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'questionid'          => new external_value(PARAM_INT,   'ID der latest-version question-Zeile'),
            'questionbankentryid' => new external_value(PARAM_INT,   'ID des question_bank_entries (Frage-Identitaet)'),
            'version'             => new external_value(PARAM_INT,   'Aktuelle Versionsnummer'),
            'name'                => new external_value(PARAM_TEXT,  'Name der Frage'),
            'questiontext'        => new external_value(PARAM_RAW,   'Fragetext (HTML)'),
            'qtype'               => new external_value(PARAM_TEXT,  'Fragetyp (i.d.R. multichoice)'),
            'defaultmark'         => new external_value(PARAM_FLOAT, 'Standard-Punktzahl der Frage'),
            'answers'             => new external_multiple_structure(
                new external_single_structure([
                    'id'       => new external_value(PARAM_INT,   'question_answers.id'),
                    'answer'   => new external_value(PARAM_RAW,   'Antwort-Text (HTML)'),
                    'fraction' => new external_value(PARAM_FLOAT, 'Bewertung (1.0=richtig, 0.0=falsch)'),
                ]),
                'Antwort-Optionen in Anlege-Reihenfolge'
            ),
            'correctindex'        => new external_value(PARAM_INT,   '0-basierter Index der richtigen Antwort in answers[] (-1 wenn keine erkannt)'),
        ]);
    }
}
